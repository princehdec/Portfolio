# Replit.md

## Overview

This is a modern 3D artist portfolio website built with React, TypeScript, and Node.js. The application showcases an artist's work across four main categories: 3D Modeling, Texturing, Animation, and Virtual Photography. It features a sleek dark theme design with a professional portfolio gallery, about section, and contact form functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design system
- **State Management**: TanStack Query for server state management and caching
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Theme System**: Custom dark/light theme provider with CSS variables

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules for modern JavaScript features
- **API Design**: RESTful API with structured error handling and request logging
- **Data Layer**: Dual storage approach - in-memory storage for development with database schema ready for production
- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)

### Database Design
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Schema**: Three main tables - portfolio_projects, contact_messages, and users
- **Migration Strategy**: Drizzle Kit for schema migrations and database management
- **Connection**: Neon Database serverless PostgreSQL with connection pooling

### Component Architecture
- **UI Components**: Radix UI primitives with custom styling via shadcn/ui
- **Layout**: Responsive design with mobile-first approach
- **Navigation**: Fixed header with smooth scrolling and active state management
- **Gallery**: Filterable portfolio grid with lightbox functionality
- **Forms**: Validated contact form with real-time feedback

### Development Workflow
- **Build System**: Vite for fast development and optimized production builds
- **Code Quality**: TypeScript strict mode with comprehensive type checking
- **Styling**: PostCSS with Tailwind CSS and autoprefixer
- **Development**: Hot module replacement with error overlay for debugging

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form, TanStack Query
- **Routing**: Wouter for lightweight client-side routing
- **Validation**: Zod for runtime type validation and schema definition

### UI and Styling
- **Component Library**: Radix UI primitives for accessible components
- **Styling Framework**: Tailwind CSS with class-variance-authority for variant management
- **Icons**: Lucide React for consistent iconography, React Icons for social media icons
- **Utilities**: clsx and tailwind-merge for conditional styling

### Database and Backend
- **Database**: Neon Database (@neondatabase/serverless) for PostgreSQL hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Store**: connect-pg-simple for PostgreSQL session storage

### Development Tools
- **Build Tool**: Vite with React plugin for fast development
- **TypeScript**: Full TypeScript setup with strict configuration
- **Dev Enhancement**: Replit-specific plugins for error handling and debugging
- **Font Loading**: Google Fonts integration for typography