// This file contains static data that matches the design reference
// The actual data comes from the API, but this serves as a reference

export const portfolioCategories = [
  { key: "modeling", label: "3D Modeling", count: 6 },
  { key: "texturing", label: "Texturing", count: 4 },
  { key: "animation", label: "Animation", count: 4 },
  { key: "photography", label: "Virtual Photography", count: 4 },
];

export const featuredProjectsCount = 4;
export const totalProjectsCount = 18;

// Skills for about section
export const skills = [
  {
    category: "3D Modeling",
    items: ["Character Design", "Hard Surface Modeling", "Organic Sculpting", "Retopology"]
  },
  {
    category: "Texturing",
    items: ["PBR Materials", "Procedural Textures", "UV Mapping", "Substance Painter"]
  },
  {
    category: "Animation",
    items: ["Character Rigging", "Motion Graphics", "Particle Systems", "Physics Simulation"]
  },
  {
    category: "Virtual Photography",
    items: ["Composition", "Lighting Design", "Post-Processing", "Cinematic Rendering"]
  }
];

// Project types for contact form
export const projectTypes = [
  "3D Modeling",
  "Texturing", 
  "Animation",
  "Virtual Photography",
  "Complete Project"
];
