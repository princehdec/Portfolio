import { AboutSection } from "@/components/about-section";

export default function About() {
  return (
    <div className="pt-20">
      <AboutSection />
    </div>
  );
}
