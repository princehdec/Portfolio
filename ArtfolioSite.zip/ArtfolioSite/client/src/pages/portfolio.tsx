import { useState } from "react";
import { PortfolioGallery } from "@/components/portfolio-gallery";
import { Lightbox } from "@/components/lightbox";

export default function Portfolio() {
  const [lightbox, setLightbox] = useState<{
    isOpen: boolean;
    src: string;
    alt: string;
  }>({
    isOpen: false,
    src: "",
    alt: "",
  });

  const openLightbox = (src: string, alt: string) => {
    setLightbox({ isOpen: true, src, alt });
  };

  const closeLightbox = () => {
    setLightbox({ isOpen: false, src: "", alt: "" });
  };

  return (
    <>
      <div className="pt-20">
        <PortfolioGallery onImageClick={openLightbox} />
      </div>
      <Lightbox
        isOpen={lightbox.isOpen}
        src={lightbox.src}
        alt={lightbox.alt}
        onClose={closeLightbox}
      />
    </>
  );
}
