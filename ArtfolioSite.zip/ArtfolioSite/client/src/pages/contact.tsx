import { ContactSection } from "@/components/contact-section";

export default function Contact() {
  return (
    <div className="pt-20">
      <ContactSection />
    </div>
  );
}
