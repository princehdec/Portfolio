import { Link } from "wouter";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { UserSettings } from "@shared/schema";

export function HeroSection() {
  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });

  // Use settings or defaults
  const displayName = settings?.name || "3D Artist";
  const bio = settings?.bio || "Specializing in modeling, texturing, animation, and virtual photography with over 3 years of professional experience crafting immersive digital worlds.";

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="3D digital artwork background" 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* 3D Floating Elements */}
      <div className="absolute inset-0 pointer-events-none z-1">
        {/* Floating Cube */}
        <div className="hero-3d-element top-20 left-10 md:top-32 md:left-20 animate-float-3d">
          <div className="w-16 h-16 md:w-24 md:h-24 bg-gradient-to-br from-primary/40 to-accent/40 shadow-2xl backdrop-blur-sm border border-primary/20" style={{transform: 'rotateX(45deg) rotateY(45deg)'}}></div>
        </div>
        
        {/* Rotating Octahedron */}
        <div className="hero-3d-element top-40 right-16 md:top-48 md:right-32 animate-rotate-3d">
          <div className="relative w-12 h-12 md:w-16 md:h-16">
            <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/40 to-pink-500/40 rotate-45 shadow-xl backdrop-blur-sm border border-purple-500/20"></div>
            <div className="absolute inset-0 bg-gradient-to-bl from-blue-500/40 to-cyan-500/40 rotate-45 shadow-xl backdrop-blur-sm border border-blue-500/20 transform translate-x-2 translate-y-2"></div>
          </div>
        </div>
        
        {/* Orbiting Ring */}
        <div className="hero-3d-element top-1/2 left-1/4 animate-orbit">
          <div className="w-20 h-20 md:w-32 md:h-32 border-4 border-primary/30 rounded-full shadow-2xl backdrop-blur-sm" style={{transform: 'rotateX(60deg)'}}></div>
        </div>
        
        {/* Floating Pyramid */}
        <div className="hero-3d-element bottom-32 left-16 md:bottom-48 md:left-32 animate-float-3d" style={{animationDelay: '-2s'}}>
          <div className="relative w-12 h-12 md:w-16 md:h-16">
            <div className="absolute inset-0 bg-gradient-to-t from-green-500/40 to-emerald-400/40 transform rotate-45 shadow-2xl backdrop-blur-sm border border-green-500/20" style={{clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)'}}></div>
          </div>
        </div>
        
        {/* Rotating Torus */}
        <div className="hero-3d-element bottom-20 right-10 md:bottom-40 md:right-24 animate-rotate-3d" style={{animationDelay: '-4s'}}>
          <div className="w-14 h-14 md:w-20 md:h-20 border-8 border-orange-500/40 rounded-full shadow-2xl backdrop-blur-sm">
            <div className="w-full h-full border-4 border-yellow-400/40 rounded-full transform scale-75"></div>
          </div>
        </div>
        
        {/* Additional Floating Hexagon */}
        <div className="hero-3d-element top-1/3 right-1/4 animate-float-3d" style={{animationDelay: '-6s'}}>
          <div className="w-10 h-10 md:w-14 md:h-14 bg-gradient-to-br from-indigo-500/40 to-purple-600/40 transform rotate-45 shadow-xl backdrop-blur-sm border border-indigo-500/20" style={{clipPath: 'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)'}}></div>
        </div>
      </div>
      
      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="animate-slide-up">
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-6">
            <span className="gradient-text">{displayName}</span>
            <br />& Digital Creator
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            {bio}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/portfolio">
              <Button 
                size="lg" 
                className="px-8 py-4 text-lg font-semibold transition-all transform hover:scale-105"
                data-testid="button-view-work"
              >
                View My Work
              </Button>
            </Link>
            <Link href="/contact">
              <Button 
                variant="outline" 
                size="lg" 
                className="px-8 py-4 text-lg font-semibold transition-all"
                data-testid="button-get-in-touch"
              >
                Get In Touch
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="text-2xl text-muted-foreground" />
      </div>
    </section>
  );
}
