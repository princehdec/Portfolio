import { SiArtstation, SiBehance, SiInstagram, SiLinkedin } from "react-icons/si";
import { useQuery } from "@tanstack/react-query";
import type { UserSettings } from "@shared/schema";

export function Footer() {
  const { data: settings } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });

  const services = [
    "3D Modeling",
    "Texturing", 
    "Animation",
    "Virtual Photography"
  ];

  const socialLinks = [
    { icon: SiArtstation, href: settings?.artstationUrl || "#", label: "ArtStation" },
    { icon: SiBehance, href: settings?.behanceUrl || "#", label: "Behance" },
    { icon: SiInstagram, href: settings?.instagramUrl || "#", label: "Instagram" },
    { icon: SiLinkedin, href: settings?.linkedinUrl || "#", label: "LinkedIn" },
  ].filter(social => social.href !== "#" && social.href !== "");

  return (
    <footer className="bg-background dark:bg-background border-t border-border py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="text-2xl font-bold gradient-text mb-4">{settings?.name || "3D Artist"}</div>
            <p className="text-muted-foreground mb-4">
              {settings?.bio || "Professional 3D artist creating immersive digital experiences through modeling, texturing, animation, and virtual photography."}
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="text-muted-foreground hover:text-accent transition-colors"
                  aria-label={social.label}
                  data-testid={`footer-social-${social.label.toLowerCase()}`}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-muted-foreground">
              {services.map((service) => (
                <li key={service}>
                  <a href="#" className="hover:text-accent transition-colors">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>{settings?.email || "contact@3dartist.com"}</li>
              {settings?.phone && <li>{settings.phone}</li>}
              {settings?.location && <li>{settings.location}</li>}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
          <p>&copy; 2024 {settings?.name || "3D Artist"}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
