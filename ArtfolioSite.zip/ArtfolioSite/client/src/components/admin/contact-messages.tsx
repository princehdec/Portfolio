import { useQuery } from "@tanstack/react-query";
import type { ContactMessage } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Mail, Clock, User, MessageSquare } from "lucide-react";
import { Loader2 } from "lucide-react";

export function ContactMessages() {
  const { data: messages, isLoading } = useQuery<ContactMessage[]>({
    queryKey: ["/api/contact/messages"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading messages...</span>
      </div>
    );
  }

  if (!messages || messages.length === 0) {
    return (
      <div className="text-center py-12">
        <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">No messages yet</h3>
        <p className="text-muted-foreground">
          Contact form submissions will appear here.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Contact Messages ({messages.length})</h3>
      </div>
      
      <ScrollArea className="h-96">
        <div className="space-y-4">
          {messages.map((message: ContactMessage, index: number) => (
            <div key={message.id}>
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-base flex items-center space-x-2">
                        <User className="h-4 w-4" />
                        <span>{message.name}</span>
                      </CardTitle>
                      <CardDescription className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Mail className="h-3 w-3" />
                          <span>{message.email}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-3 w-3" />
                          <span>
                            {message.createdAt ? new Date(message.createdAt).toLocaleDateString() : 'N/A'}
                          </span>
                        </div>
                      </CardDescription>
                    </div>
                    <Badge variant="secondary">
                      {message.projectType}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="bg-muted/50 rounded-lg p-4">
                    <p className="text-sm leading-relaxed">
                      {message.message}
                    </p>
                  </div>
                </CardContent>
              </Card>
              {index < messages.length - 1 && <Separator className="my-4" />}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}