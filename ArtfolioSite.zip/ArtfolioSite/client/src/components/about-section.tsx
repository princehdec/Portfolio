import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { UserSettings } from "@shared/schema";

export function AboutSection() {
  const { data: settings } = useQuery<UserSettings>({
    queryKey: ["/api/settings"],
  });

  const skills = [
    {
      title: "3D Modeling",
      description: "Character design, hard surface modeling, organic sculpting"
    },
    {
      title: "Texturing",
      description: "PBR materials, procedural textures, UV mapping"
    },
    {
      title: "Animation",
      description: "Character rigging, motion graphics, particle systems"
    },
    {
      title: "Virtual Photography",
      description: "Composition, lighting design, post-processing"
    }
  ];

  return (
    <section className="py-20 bg-background dark:bg-background">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-up">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">About Me</h2>
            <p className="text-lg text-muted-foreground mb-6">
              {settings?.bio || "With over 3 years of professional experience in 3D artistry, I specialize in bringing digital worlds to life through meticulous modeling, innovative texturing techniques, fluid animation, and compelling virtual photography."}
            </p>
            
            {/* Skills Grid */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {skills.map((skill, index) => (
                <div 
                  key={index} 
                  className="bg-card dark:bg-card p-4 rounded-lg"
                  data-testid={`skill-${skill.title.toLowerCase().replace(' ', '-')}`}
                >
                  <h4 className="font-semibold mb-2 text-accent">{skill.title}</h4>
                  <p className="text-sm text-muted-foreground">{skill.description}</p>
                </div>
              ))}
            </div>
            
            <Button 
              className="inline-flex items-center px-6 py-3 font-semibold transition-all"
              data-testid="button-download-resume"
            >
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </Button>
          </div>
          
          <div className="relative">
            {/* Professional portrait */}
            <div className="aspect-square rounded-2xl overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600" 
                alt={`${settings?.name || '3D Artist'} - Professional Portrait`} 
                className="w-full h-full object-cover"
                data-testid="profile-image"
              />
            </div>
            
            {/* Experience Badge */}
            <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-xl text-center">
              <div className="text-3xl font-bold">3+</div>
              <div className="text-sm">Years Experience</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
