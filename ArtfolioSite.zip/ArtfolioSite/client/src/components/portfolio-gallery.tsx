import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { PortfolioProject } from "@shared/schema";

interface PortfolioGalleryProps {
  onImageClick?: (src: string, alt: string) => void;
}

export function PortfolioGallery({ onImageClick }: PortfolioGalleryProps) {
  const [activeFilter, setActiveFilter] = useState("all");

  const { data: projects, isLoading } = useQuery<PortfolioProject[]>({
    queryKey: ["/api/portfolio"],
  });

  const filteredProjects = projects?.filter(project => 
    activeFilter === "all" || project.category === activeFilter
  ) || [];

  const filterButtons = [
    { key: "all", label: "All Works" },
    { key: "modeling", label: "3D Modeling" },
    { key: "texturing", label: "Texturing" },
    { key: "animation", label: "Animation" },
    { key: "photography", label: "Virtual Photography" },
  ];

  if (isLoading) {
    return (
      <section className="py-20 bg-card dark:bg-card">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Portfolio</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Explore my diverse collection of 3D artworks, from detailed character models to stunning virtual photography.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="bg-secondary dark:bg-secondary rounded-xl h-64 animate-pulse" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-card dark:bg-card">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Portfolio</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore my diverse collection of 3D artworks, from detailed character models to stunning virtual photography.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filterButtons.map((filter) => (
            <Button
              key={filter.key}
              variant={activeFilter === filter.key ? "default" : "secondary"}
              className="px-6 py-3 font-semibold transition-all"
              onClick={() => setActiveFilter(filter.key)}
              data-testid={`filter-${filter.key}`}
            >
              {filter.label}
            </Button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="portfolio-item cursor-pointer"
              data-testid={`portfolio-item-${project.id}`}
            >
              <div className="relative group overflow-hidden rounded-xl bg-secondary dark:bg-secondary">
                <img 
                  src={project.imageUrl} 
                  alt={project.title}
                  className="w-full h-64 object-cover transition-transform group-hover:scale-110"
                  onClick={() => onImageClick?.(project.imageUrl, project.title)}
                  data-testid={`image-${project.id}`}
                />
                <div className="portfolio-overlay absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-2 text-white">{project.title}</h3>
                    <p className="text-sm text-gray-300">{project.description}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No projects found for this category.</p>
          </div>
        )}
      </div>
    </section>
  );
}
