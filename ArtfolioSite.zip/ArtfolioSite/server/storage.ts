import { type User, type InsertUser, type PortfolioProject, type InsertPortfolioProject, type ContactMessage, type InsertContactMessage, type UserSettings, type InsertUserSettings, type UpdateUserSettings } from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  authenticateUser(username: string, password: string): Promise<User | null>;
  
  // Portfolio methods
  getPortfolioProjects(): Promise<PortfolioProject[]>;
  getPortfolioProjectsByCategory(category: string): Promise<PortfolioProject[]>;
  getFeaturedProjects(): Promise<PortfolioProject[]>;
  createPortfolioProject(project: InsertPortfolioProject): Promise<PortfolioProject>;
  updatePortfolioProject(id: string, project: Partial<InsertPortfolioProject>): Promise<PortfolioProject>;
  deletePortfolioProject(id: string): Promise<boolean>;
  
  // Contact methods
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  
  // User settings methods
  getUserSettings(): Promise<UserSettings>;
  updateUserSettings(settings: UpdateUserSettings): Promise<UserSettings>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private portfolioProjects: Map<string, PortfolioProject>;
  private contactMessages: Map<string, ContactMessage>;
  private userSettings: UserSettings;

  constructor() {
    this.users = new Map();
    this.portfolioProjects = new Map();
    this.contactMessages = new Map();
    
    // Initialize default user settings
    this.userSettings = {
      id: "default",
      name: "Your Name",
      email: "your@email.com",
      phone: "+1 (555) 123-4567",
      location: "Your Location",
      bio: "Professional 3D artist creating immersive digital experiences through modeling, texturing, animation, and virtual photography.",
      artstationUrl: null,
      behanceUrl: null,
      instagramUrl: null,
      linkedinUrl: null,
      updatedAt: new Date(),
    };
    
    // Initialize with sample portfolio data
    this.initializePortfolioData();
  }

  private initializePortfolioData() {
    const sampleProjects: InsertPortfolioProject[] = [
      // 3D Modeling
      {
        title: "Character Model",
        description: "Detailed humanoid character with advanced facial rigging",
        category: "modeling",
        imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 1
      },
      {
        title: "Architectural Visualization",
        description: "Modern building complex with detailed interior layouts",
        category: "modeling",
        imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Sci-Fi Vehicle",
        description: "Futuristic spacecraft with detailed mechanical components",
        category: "modeling",
        imageUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 1
      },
      {
        title: "Fantasy Sword",
        description: "Ornate medieval weapon with magical enchantments",
        category: "modeling",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Mythical Creature",
        description: "Fantasy beast with detailed anatomy and scales",
        category: "modeling",
        imageUrl: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Sports Car Model",
        description: "High-detail automotive model with accurate proportions",
        category: "modeling",
        imageUrl: "https://images.unsplash.com/photo-1493238792000-8113da705763?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      
      // Texturing
      {
        title: "Fabric Materials",
        description: "Photorealistic textile textures with proper subsurface scattering",
        category: "texturing",
        imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Weathered Metal",
        description: "Industrial metal surfaces with rust and wear patterns",
        category: "texturing",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 1
      },
      {
        title: "Character Skin",
        description: "Realistic human skin with pore detail and subsurface scattering",
        category: "texturing",
        imageUrl: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Natural Wood",
        description: "Detailed wood grain patterns with realistic material properties",
        category: "texturing",
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      
      // Animation
      {
        title: "Character Walk Cycle",
        description: "Smooth locomotion animation with proper weight distribution",
        category: "animation",
        imageUrl: "https://images.unsplash.com/photo-1633356122102-3fe601e05bd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Mechanical Assembly",
        description: "Complex machinery animation with precise timing",
        category: "animation",
        imageUrl: "https://images.unsplash.com/photo-1462899006636-339e08d1844e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Particle Effects",
        description: "Dynamic fire and smoke simulations with realistic physics",
        category: "animation",
        imageUrl: "https://images.unsplash.com/photo-1462899006636-339e08d1844e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 1
      },
      {
        title: "Fluid Dynamics",
        description: "Realistic water simulation with accurate surface tension",
        category: "animation",
        imageUrl: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      
      // Virtual Photography
      {
        title: "Virtual Landscape",
        description: "Atmospheric outdoor scene with volumetric lighting",
        category: "photography",
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Interior Architecture",
        description: "Modern interior space with natural lighting",
        category: "photography",
        imageUrl: "https://images.unsplash.com/photo-1493238792000-8113da705763?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Product Showcase",
        description: "Commercial product render with studio lighting",
        category: "photography",
        imageUrl: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 0
      },
      {
        title: "Abstract Composition",
        description: "Experimental lighting and geometric forms",
        category: "photography",
        imageUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: 1
      }
    ];

    sampleProjects.forEach(project => {
      this.createPortfolioProject(project);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(insertUser.password, saltRounds);
    const user: User = { 
      ...insertUser, 
      id, 
      password: hashedPassword 
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async authenticateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (user && await bcrypt.compare(password, user.password)) {
      return user;
    }
    return null;
  }

  async getPortfolioProjects(): Promise<PortfolioProject[]> {
    return Array.from(this.portfolioProjects.values());
  }

  async getPortfolioProjectsByCategory(category: string): Promise<PortfolioProject[]> {
    return Array.from(this.portfolioProjects.values()).filter(
      project => project.category === category
    );
  }

  async getFeaturedProjects(): Promise<PortfolioProject[]> {
    return Array.from(this.portfolioProjects.values()).filter(
      project => project.featured === 1
    );
  }

  async createPortfolioProject(insertProject: InsertPortfolioProject): Promise<PortfolioProject> {
    const id = randomUUID();
    const project: PortfolioProject = {
      ...insertProject,
      id,
      featured: insertProject.featured ?? 0,
      createdAt: new Date(),
    };
    this.portfolioProjects.set(id, project);
    return project;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = randomUUID();
    const message: ContactMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }

  async updatePortfolioProject(id: string, updateData: Partial<InsertPortfolioProject>): Promise<PortfolioProject> {
    const existingProject = this.portfolioProjects.get(id);
    if (!existingProject) {
      throw new Error(`Portfolio project with id ${id} not found`);
    }
    
    const updatedProject: PortfolioProject = {
      ...existingProject,
      ...updateData,
      featured: updateData.featured ?? existingProject.featured,
    };
    
    this.portfolioProjects.set(id, updatedProject);
    return updatedProject;
  }

  async deletePortfolioProject(id: string): Promise<boolean> {
    return this.portfolioProjects.delete(id);
  }

  async getUserSettings(): Promise<UserSettings> {
    return this.userSettings;
  }

  async updateUserSettings(updateData: UpdateUserSettings): Promise<UserSettings> {
    this.userSettings = {
      ...this.userSettings,
      ...updateData,
      updatedAt: new Date(),
    };
    return this.userSettings;
  }
}

export const storage = new MemStorage();
