import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import { insertContactMessageSchema, insertPortfolioProjectSchema, updateUserSettingsSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

// Authentication middleware
function requireAuth(req: any, res: any, next: any) {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.status(401).json({ message: "Authentication required" });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Ensure uploads directory exists
  const uploadsDir = path.join(process.cwd(), 'client', 'public', 'uploads');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  // Configure multer for file uploads
  const upload = multer({
    storage: multer.diskStorage({
      destination: uploadsDir,
      filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
      }
    }),
    fileFilter: (req, file, cb) => {
      const allowedTypes = /jpeg|jpg|png|gif|webp/;
      const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
      const mimetype = allowedTypes.test(file.mimetype);
      
      if (mimetype && extname) {
        return cb(null, true);
      } else {
        cb(new Error('Only image files are allowed!'));
      }
    },
    limits: {
      fileSize: 10 * 1024 * 1024 // 10MB limit
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    next();
  }, express.static(uploadsDir));
  // Get all portfolio projects
  app.get("/api/portfolio", async (_req, res) => {
    try {
      const projects = await storage.getPortfolioProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch portfolio projects" });
    }
  });

  // Get projects by category
  app.get("/api/portfolio/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const projects = await storage.getPortfolioProjectsByCategory(category);
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects by category" });
    }
  });

  // Get featured projects
  app.get("/api/portfolio/featured", async (_req, res) => {
    try {
      const projects = await storage.getFeaturedProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured projects" });
    }
  });

  // Submit contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.status(201).json({ 
        success: true, 
        message: "Thank you for your message! I'll get back to you soon.",
        id: message.id 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid form data", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ message: "Failed to submit contact message" });
      }
    }
  });

  // Get all contact messages (admin endpoint)
  app.get("/api/contact/messages", requireAuth, async (_req, res) => {
    try {
      const messages = await storage.getContactMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contact messages" });
    }
  });

  // User Settings endpoints
  // Public endpoint to get settings (for frontend display)
  app.get("/api/settings", async (_req, res) => {
    try {
      const settings = await storage.getUserSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });

  app.put("/api/settings", requireAuth, async (req, res) => {
    try {
      const validatedData = updateUserSettingsSchema.parse(req.body);
      const settings = await storage.updateUserSettings(validatedData);
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid settings data", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ message: "Failed to update settings" });
      }
    }
  });

  // Portfolio management endpoints
  app.post("/api/portfolio", requireAuth, upload.single('image'), async (req, res) => {
    try {
      const projectData = {
        title: req.body.title,
        description: req.body.description,
        category: req.body.category,
        featured: parseInt(req.body.featured) || 0,
        imageUrl: req.file ? `/uploads/${req.file.filename}` : req.body.imageUrl || ""
      };
      
      const validatedData = insertPortfolioProjectSchema.parse(projectData);
      const project = await storage.createPortfolioProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid project data", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ message: "Failed to create project" });
      }
    }
  });

  app.put("/api/portfolio/:id", requireAuth, upload.single('image'), async (req, res) => {
    try {
      const { id } = req.params;
      const updateData: any = {
        title: req.body.title,
        description: req.body.description,
        category: req.body.category,
        featured: req.body.featured !== undefined ? parseInt(req.body.featured) : undefined,
      };
      
      if (req.file) {
        updateData.imageUrl = `/uploads/${req.file.filename}`;
      }
      
      // Remove undefined values
      Object.keys(updateData).forEach(key => 
        updateData[key] === undefined && delete updateData[key]
      );
      
      const project = await storage.updatePortfolioProject(id, updateData);
      res.json(project);
    } catch (error) {
      if (error instanceof Error && error.message.includes('not found')) {
        res.status(404).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to update project" });
      }
    }
  });

  app.delete("/api/portfolio/:id", requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deletePortfolioProject(id);
      
      if (deleted) {
        res.json({ success: true, message: "Project deleted successfully" });
      } else {
        res.status(404).json({ message: "Project not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = {
        username: req.body.username,
        password: req.body.password,
      };

      const user = await storage.authenticateUser(loginData.username, loginData.password);
      
      if (user) {
        // Store user session
        (req.session as any).userId = user.id;
        (req.session as any).username = user.username;
        res.json({ success: true, message: "Login successful" });
      } else {
        res.status(401).json({ message: "Invalid credentials" });
      }
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        res.status(500).json({ message: "Logout failed" });
      } else {
        res.clearCookie('connect.sid');
        res.json({ success: true, message: "Logged out successfully" });
      }
    });
  });

  app.get("/api/auth/check", (req, res) => {
    const session = req.session as any;
    if (session.userId) {
      res.json({ authenticated: true, username: session.username });
    } else {
      res.status(401).json({ authenticated: false });
    }
  });

  // Check if setup is needed
  app.get("/api/auth/setup/status", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json({ needsSetup: users.length === 0 });
    } catch (error) {
      res.status(500).json({ message: "Failed to check setup status" });
    }
  });

  // Create default admin user if none exists
  app.post("/api/auth/setup", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      if (users.length > 0) {
        res.status(400).json({ message: "Setup already completed" });
        return;
      }

      const { username, password } = insertUserSchema.parse(req.body);
      const user = await storage.createUser({ username, password });
      res.json({ success: true, message: "Admin user created successfully" });
    } catch (error) {
      res.status(500).json({ message: "Setup failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
